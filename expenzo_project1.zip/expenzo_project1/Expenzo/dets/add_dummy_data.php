<?php
include('includes/dbconnection.php');

// Add dummy users
$dummy_users = [
    ['John Doe', 'john@example.com', '1234567890', '2024-01-01', 1],
    ['Jane Smith', 'jane@example.com', '9876543210', '2024-01-02', 1],
    ['Bob Johnson', 'bob@example.com', '5555555555', '2024-01-03', 0],
    ['Alice Brown', 'alice@example.com', '4444444444', '2024-01-04', 1],
    ['Charlie Wilson', 'charlie@example.com', '3333333333', '2024-01-05', 1]
];

foreach ($dummy_users as $user) {
    $name = $user[0];
    $email = $user[1];
    $mobile = $user[2];
    $date = $user[3];
    $status = $user[4];
    $password = md5('password123');
    
    mysqli_query($con, "INSERT INTO tbluser (FullName, Email, MobileNumber, Password, RegDate, Status) 
                       VALUES ('$name', '$email', '$mobile', '$password', '$date', $status)");
}

// Add dummy expenses
$expense_categories = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment'];
$user_ids = range(1, 5); // Assuming we have 5 users

for ($i = 0; $i < 20; $i++) {
    $user_id = $user_ids[array_rand($user_ids)];
    $category = $expense_categories[array_rand($expense_categories)];
    $amount = rand(100, 1000);
    $date = date('Y-m-d', strtotime("-" . rand(0, 30) . " days"));
    
    mysqli_query($con, "INSERT INTO tblexpense (UserId, ExpenseCategory, ExpenseCost, ExpenseDate) 
                       VALUES ($user_id, '$category', $amount, '$date')");
}

// Add dummy income
$income_categories = ['Salary', 'Freelance', 'Business', 'Investment', 'Other'];
$user_ids = range(1, 5);

for ($i = 0; $i < 20; $i++) {
    $user_id = $user_ids[array_rand($user_ids)];
    $category = $income_categories[array_rand($income_categories)];
    $amount = rand(1000, 5000);
    $date = date('Y-m-d', strtotime("-" . rand(0, 30) . " days"));
    
    mysqli_query($con, "INSERT INTO tblincome (UserId, IncomeCategory, IncomeCost, IncomeDate) 
                       VALUES ($user_id, '$category', $amount, '$date')");
}

echo "Dummy data added successfully!";
?> 