<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get admin details
$adminid = $_SESSION['adminid'];
$adminname = $_SESSION['adminname'];

// Initialize variables with default values
$total_users = 0;
$total_expenses = 0;
$total_income = 0;
$active_users = 0;

// Get statistics with error handling
$query = mysqli_query($con, "SELECT COUNT(*) as total FROM tbluser");
if ($query) {
    $total_users = mysqli_fetch_assoc($query)['total'];
}

$query = mysqli_query($con, "SELECT COUNT(*) as total FROM tbluser WHERE Status=1");
if ($query) {
    $active_users = mysqli_fetch_assoc($query)['total'];
}

$query = mysqli_query($con, "SELECT COALESCE(SUM(ExpenseCost), 0) as total FROM tblexpense");
if ($query) {
    $total_expenses = mysqli_fetch_assoc($query)['total'];
}

$query = mysqli_query($con, "SELECT COALESCE(SUM(IncomeCost), 0) as total FROM tblincome");
if ($query) {
    $total_income = mysqli_fetch_assoc($query)['total'];
}

// Get recent activities with error handling
$recent_users = mysqli_query($con, "SELECT * FROM tbluser ORDER BY ID DESC LIMIT 5");
if (!$recent_users) {
    $recent_users = array();
}

$recent_expenses = mysqli_query($con, "SELECT e.*, u.FullName FROM tblexpense e JOIN tbluser u ON e.UserId=u.ID ORDER BY e.ID DESC LIMIT 5");
if (!$recent_expenses) {
    $recent_expenses = array();
}

$recent_income = mysqli_query($con, "SELECT i.*, u.FullName FROM tblincome i JOIN tbluser u ON i.UserId=u.ID ORDER BY i.ID DESC LIMIT 5");
if (!$recent_income) {
    $recent_income = array();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Expenzo</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: inherit;
            max-width: inherit;
            z-index: 1000;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover {
            background: #34495e;
            padding-left: 25px;
            border-left: 4px solid #3498db;
        }
        .sidebar .active {
            background: #3498db;
            border-left: 4px solid #fff;
        }
        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        .main-content {
            padding: 30px;
            margin-left: 16.666667%;
            min-height: 100vh;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            border-top: 4px solid #3498db;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card i {
            font-size: 45px;
            margin-bottom: 15px;
            opacity: 0.8;
        }
        .stat-card .number {
            font-size: 28px;
            font-weight: bold;
            margin: 10px 0;
        }
        .stat-card .label {
            color: #666;
            font-size: 16px;
        }
        .recent-activity {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .recent-activity h4 {
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f8f9fa;
        }
        .recent-activity h4 i {
            margin-right: 10px;
            color: #3498db;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            border-top: none;
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 600;
        }
        .table td {
            vertical-align: middle;
        }
        .welcome-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .welcome-section h2 {
            color: #2c3e50;
            margin: 0;
            font-weight: 600;
        }
        .welcome-section hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        .label {
            padding: 5px 10px;
            border-radius: 15px;
            font-weight: 500;
        }
        .label-success {
            background-color: #2ecc71;
            color: white;
        }
        .label-danger {
            background-color: #e74c3c;
            color: white;
        }
        .text-primary { color: #3498db !important; }
        .text-success { color: #2ecc71 !important; }
        .text-danger { color: #e74c3c !important; }
        .text-info { color: #3498db !important; }
        .page-header {
            margin-bottom: 30px;
        }
        .page-header h2 {
            color: #2c3e50;
            font-weight: 600;
            margin: 0;
        }
        .page-header hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h3 class="text-center mb-4">Expenzo Admin</h3>
                <nav>
                    <a href="admin_dashboard.php" class="active">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                    <a href="manage_users.php">
                        <i class="fa fa-users"></i> Manage Users
                    </a>
                    <a href="manage_expenses.php">
                        <i class="fa fa-money"></i> Manage Expenses
                    </a>
                    <a href="manage_income.php">
                        <i class="fa fa-line-chart"></i> Manage Income
                    </a>
                    <a href="reports.php">
                        <i class="fa fa-bar-chart"></i> Reports
                    </a>
                    <a href="settings.php">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Welcome Section -->
                <div class="welcome-section">
                    <h2>Welcome, <?php echo htmlspecialchars($adminname); ?></h2>
                    <hr>
                </div>

                <!-- Statistics Cards -->
                <div class="row">
                    <div class="col-md-3">
                        <div class="stat-card text-center">
                            <i class="fa fa-users text-primary"></i>
                            <div class="number"><?php echo $total_users; ?></div>
                            <div class="label">Total Users</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card text-center">
                            <i class="fa fa-user text-success"></i>
                            <div class="number"><?php echo $active_users; ?></div>
                            <div class="label">Active Users</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card text-center">
                            <i class="fa fa-money text-danger"></i>
                            <div class="number">₹<?php echo number_format($total_expenses, 2); ?></div>
                            <div class="label">Total Expenses</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-card text-center">
                            <i class="fa fa-line-chart text-info"></i>
                            <div class="number">₹<?php echo number_format($total_income, 2); ?></div>
                            <div class="label">Total Income</div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="recent-activity">
                            <h4><i class="fa fa-users"></i> Recent Users</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_object($recent_users)): while($user = mysqli_fetch_assoc($recent_users)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['FullName']); ?></td>
                                            <td><?php echo htmlspecialchars($user['Email']); ?></td>
                                            <td>
                                                <?php if(isset($user['Status']) && $user['Status'] == 1): ?>
                                                    <span class="label label-success">Active</span>
                                                <?php else: ?>
                                                    <span class="label label-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="recent-activity">
                            <h4><i class="fa fa-money"></i> Recent Expenses</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_object($recent_expenses)): while($expense = mysqli_fetch_assoc($recent_expenses)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($expense['FullName']); ?></td>
                                            <td><?php echo htmlspecialchars(isset($expense['ExpenseCategory']) ? $expense['ExpenseCategory'] : 'Uncategorized'); ?></td>
                                            <td>₹<?php echo htmlspecialchars($expense['ExpenseCost']); ?></td>
                                        </tr>
                                        <?php endwhile; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="recent-activity">
                            <h4><i class="fa fa-line-chart"></i> Recent Income</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_object($recent_income)): while($income = mysqli_fetch_assoc($recent_income)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($income['FullName']); ?></td>
                                            <td><?php echo htmlspecialchars(isset($income['IncomeCategory']) ? $income['IncomeCategory'] : 'Uncategorized'); ?></td>
                                            <td>₹<?php echo htmlspecialchars($income['IncomeCost']); ?></td>
                                        </tr>
                                        <?php endwhile; endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 