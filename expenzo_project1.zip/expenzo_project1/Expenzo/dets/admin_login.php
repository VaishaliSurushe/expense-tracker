<?php
session_start();
include('includes/dbconnection.php');

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = md5($_POST['password']);

    // Debug information
    error_log("Login attempt - Username: " . $username);
    error_log("Password hash: " . $password);
    
    // First check if user exists
    $check_user = mysqli_query($con, "SELECT * FROM users WHERE username='$username'");
    if ($user = mysqli_fetch_assoc($check_user)) {
        error_log("User found in database");
        error_log("Stored password hash: " . $user['password']);
        error_log("Is admin: " . $user['is_admin']);
    } else {
        error_log("User not found in database");
    }
    
    $query = mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND password='$password' AND is_admin=1");
    
    if (!$query) {
        error_log("Query error: " . mysqli_error($con));
        $msg = "Database error occurred.";
    } else {
        $row = mysqli_fetch_assoc($query);
        
        if ($row) {
            error_log("Login successful for user: " . $username);
            $_SESSION['adminid'] = $row['id'];
            $_SESSION['adminname'] = $row['username'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            error_log("Login failed - Invalid credentials for username: " . $username);
            $msg = "Invalid username or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login - Expenzo</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
</head>
<body class="login-page">
    <div class="row">
        <h2 align="center" class="head">Expenzo Admin</h2>
        <hr />
        <div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default login-conatiner">
                <div class="panel-heading login-conatiner">Admin Login</div>
                <hr class="hr-login"/>
                <div class="panel-body">
                    <?php if(isset($msg)): ?>
                        <div class="alert alert-danger">
                            <?php echo htmlspecialchars($msg); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form role="form" action="" method="post" id="loginForm">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="Username" name="username" type="text" autofocus required>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="password" type="password" required>
                            </div>
                            <button type="submit" name="login" class="btn btn-primary btn-block">Login</button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
