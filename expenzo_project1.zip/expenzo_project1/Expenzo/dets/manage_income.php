<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get admin details
$adminid = $_SESSION['adminid'];
$adminname = $_SESSION['adminname'];

// Handle income deletion
if(isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($con, $_GET['delete']);
    mysqli_query($con, "DELETE FROM tblincome WHERE ID='$id'");
    header("Location: manage_income.php");
    exit();
}

// Get filter parameters
$user_filter = isset($_GET['user']) ? mysqli_real_escape_string($con, $_GET['user']) : '';
$category_filter = isset($_GET['category']) ? mysqli_real_escape_string($con, $_GET['category']) : '';
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($con, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($con, $_GET['date_to']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';

// Build query
$query = "SELECT i.*, u.FullName FROM tblincome i JOIN tbluser u ON i.UserId=u.ID WHERE 1=1";
if($user_filter) $query .= " AND i.UserId='$user_filter'";
if($category_filter) $query .= " AND i.IncomeCategory='$category_filter'";
if($date_from) $query .= " AND i.IncomeDate >= '$date_from'";
if($date_to) $query .= " AND i.IncomeDate <= '$date_to'";
if($search) $query .= " AND (i.IncomeCategory LIKE '%$search%' OR u.FullName LIKE '%$search%')";
$query .= " ORDER BY i.ID DESC";

$income = mysqli_query($con, $query);

// Get all users and categories for filters
$users = mysqli_query($con, "SELECT * FROM tbluser ORDER BY FullName");
$categories = mysqli_query($con, "SELECT DISTINCT IncomeCategory FROM tblincome ORDER BY IncomeCategory");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Income - Expenzo Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: inherit;
            max-width: inherit;
            z-index: 1000;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover {
            background: #34495e;
            padding-left: 25px;
            border-left: 4px solid #3498db;
        }
        .sidebar .active {
            background: #3498db;
            border-left: 4px solid #fff;
        }
        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        .main-content {
            padding: 30px;
            margin-left: 16.666667%;
            min-height: 100vh;
        }
        .page-header {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .page-header h2 {
            color: #2c3e50;
            margin: 0;
            font-weight: 600;
        }
        .page-header hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        .filter-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .data-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            border-top: none;
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 600;
        }
        .table td {
            vertical-align: middle;
        }
        .btn-action {
            padding: 5px 10px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h3 class="text-center mb-4">Expenzo Admin</h3>
                <nav>
                    <a href="admin_dashboard.php">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                    <a href="manage_users.php">
                        <i class="fa fa-users"></i> Manage Users
                    </a>
                    <a href="manage_expenses.php">
                        <i class="fa fa-money"></i> Manage Expenses
                    </a>
                    <a href="manage_income.php" class="active">
                        <i class="fa fa-line-chart"></i> Manage Income
                    </a>
                    <a href="reports.php">
                        <i class="fa fa-bar-chart"></i> Reports
                    </a>
                    <a href="settings.php">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h2>Manage Income</h2>
                    <hr>
                </div>

                <!-- Filter Section -->
                <div class="filter-section">
                    <form method="GET" class="row">
                        <div class="col-md-3 mb-3">
                            <label>User</label>
                            <select name="user" class="form-control">
                                <option value="">All Users</option>
                                <?php while($user = mysqli_fetch_assoc($users)): ?>
                                    <option value="<?php echo $user['ID']; ?>" <?php echo $user_filter == $user['ID'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($user['FullName']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>Category</label>
                            <select name="category" class="form-control">
                                <option value="">All Categories</option>
                                <?php while($category = mysqli_fetch_assoc($categories)): ?>
                                    <option value="<?php echo $category['IncomeCategory']; ?>" <?php echo $category_filter == $category['IncomeCategory'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['IncomeCategory']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>Date From</label>
                            <input type="date" name="date_from" class="form-control" value="<?php echo $date_from; ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>Date To</label>
                            <input type="date" name="date_to" class="form-control" value="<?php echo $date_to; ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>Search</label>
                            <input type="text" name="search" class="form-control" placeholder="Search..." value="<?php echo $search; ?>">
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                            <a href="manage_income.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>

                <!-- Data Section -->
                <div class="data-section">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_assoc($income)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['FullName']); ?></td>
                                    <td><?php echo htmlspecialchars($row['IncomeCategory']); ?></td>
                                    <td>₹<?php echo htmlspecialchars($row['IncomeCost']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($row['IncomeDate'])); ?></td>
                                    <td>
                                        <a href="manage_income.php?delete=<?php echo $row['ID']; ?>" 
                                           class="btn btn-danger btn-action"
                                           onclick="return confirm('Are you sure you want to delete this income?')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 