<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get admin details
$adminid = $_SESSION['adminid'];
$adminname = $_SESSION['adminname'];

// Handle user status toggle
if(isset($_GET['toggle_status'])) {
    $userid = mysqli_real_escape_string($con, $_GET['toggle_status']);
    $status_query = mysqli_query($con, "SELECT Status FROM tbluser WHERE ID='$userid'");
    
    if ($status_query === false) {
        $error_message = "Database error occurred. Please try again.";
    } else {
        $status_row = mysqli_fetch_assoc($status_query);
        if ($status_row) {
            $current_status = $status_row['Status'] ?? 'Inactive';
            $new_status = $current_status == 'Active' ? 'Inactive' : 'Active';
            
            $update_query = mysqli_query($con, "UPDATE tbluser SET Status='$new_status' WHERE ID='$userid'");
            if ($update_query === false) {
                $error_message = "Failed to update user status. Please try again.";
            } else {
                $success_message = "User status updated successfully!";
            }
        } else {
            $error_message = "User not found.";
        }
    }
    
    if (isset($error_message) || isset($success_message)) {
        header("Location: manage_users.php?message=" . urlencode($error_message ?? $success_message));
        exit();
    }
}

// Handle user deletion
if(isset($_GET['delete'])) {
    $userid = mysqli_real_escape_string($con, $_GET['delete']);
    $delete_query = mysqli_query($con, "DELETE FROM tbluser WHERE ID='$userid'");
    
    if ($delete_query === false) {
        $error_message = "Failed to delete user. Please try again.";
    } else {
        $success_message = "User deleted successfully!";
    }
    
    header("Location: manage_users.php?message=" . urlencode($error_message ?? $success_message));
    exit();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? mysqli_real_escape_string($con, $_GET['status']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';

// Build query
$query = "SELECT * FROM tbluser WHERE 1=1";
if($status_filter) $query .= " AND Status='$status_filter'";
if($search) $query .= " AND (FullName LIKE '%$search%' OR Email LIKE '%$search%' OR MobileNumber LIKE '%$search%')";
$query .= " ORDER BY ID DESC";

$users = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users - Expenzo Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: inherit;
            max-width: inherit;
            z-index: 1000;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover {
            background: #34495e;
            padding-left: 25px;
            border-left: 4px solid #3498db;
        }
        .sidebar .active {
            background: #3498db;
            border-left: 4px solid #fff;
        }
        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        .main-content {
            padding: 30px;
            margin-left: 16.666667%;
            min-height: 100vh;
        }
        .page-header {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .page-header h2 {
            color: #2c3e50;
            margin: 0;
            font-weight: 600;
        }
        .page-header hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        .filter-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .data-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            border-top: none;
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 600;
        }
        .table td {
            vertical-align: middle;
        }
        .btn-action {
            padding: 5px 10px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-active {
            background-color: #d4edda;
            color: #155724;
        }
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h3 class="text-center mb-4">Expenzo Admin</h3>
                <nav>
                    <a href="admin_dashboard.php">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                    <a href="manage_users.php" class="active">
                        <i class="fa fa-users"></i> Manage Users
                    </a>
                    <a href="manage_expenses.php">
                        <i class="fa fa-money"></i> Manage Expenses
                    </a>
                    <a href="manage_income.php">
                        <i class="fa fa-line-chart"></i> Manage Income
                    </a>
                    <a href="reports.php">
                        <i class="fa fa-bar-chart"></i> Reports
                    </a>
                    <a href="settings.php">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h2>Manage Users</h2>
                    <hr>
                </div>

                <!-- Filter Section -->
                <div class="filter-section">
                    <form method="GET" class="row">
                        <div class="col-md-4 mb-3">
                            <label>Status</label>
                            <select name="status" class="form-control">
                                <option value="">All Status</option>
                                <option value="Active" <?php echo $status_filter == 'Active' ? 'selected' : ''; ?>>Active</option>
                                <option value="Inactive" <?php echo $status_filter == 'Inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Search</label>
                            <input type="text" name="search" class="form-control" placeholder="Search by name, email or mobile..." value="<?php echo $search; ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Apply Filters</button>
                        </div>
                        <div class="col-md-12">
                            <a href="manage_users.php" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>

                <!-- Data Section -->
                <div class="data-section">
                    <?php if (isset($_GET['message'])): ?>
                        <div class="alert <?php echo strpos($_GET['message'], 'successfully') !== false ? 'alert-success' : 'alert-danger'; ?>">
                            <?php echo htmlspecialchars($_GET['message']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($user = mysqli_fetch_assoc($users)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['FullName']); ?></td>
                                    <td><?php echo htmlspecialchars($user['Email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['MobileNumber']); ?></td>
                                    <td>
                                        <?php 
                                        // Get status with default value of 'Inactive' if not set
                                        $user_status = $user['Status'] ?? 'Inactive';
                                        $status_class = $user_status == 'Active' ? 'status-active' : 'status-inactive';
                                        ?>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <?php echo htmlspecialchars($user_status); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="manage_users.php?toggle_status=<?php echo $user['ID']; ?>" 
                                           class="btn btn-warning btn-action"
                                           onclick="return confirm('Are you sure you want to <?php echo $user_status == 'Active' ? 'deactivate' : 'activate'; ?> this user?')">
                                            <i class="fa fa-power-off"></i>
                                        </a>
                                        <a href="manage_users.php?delete=<?php echo $user['ID']; ?>" 
                                           class="btn btn-danger btn-action"
                                           onclick="return confirm('Are you sure you want to delete this user?')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 