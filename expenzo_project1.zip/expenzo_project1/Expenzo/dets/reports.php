<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get admin details
$adminid = $_SESSION['adminid'];
$adminname = $_SESSION['adminname'];

// Get date range
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($con, $_GET['date_from']) : date('Y-m-01');
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($con, $_GET['date_to']) : date('Y-m-d');

// Initialize variables with default values
$total_income = 0;
$total_expenses = 0;
$net_balance = 0;

// Get total income and expenses with error handling
$query = mysqli_query($con, "SELECT COALESCE(SUM(IncomeCost), 0) as total FROM tblincome WHERE IncomeDate BETWEEN '$date_from' AND '$date_to'");
if ($query) {
    $total_income = mysqli_fetch_assoc($query)['total'];
}

$query = mysqli_query($con, "SELECT COALESCE(SUM(ExpenseCost), 0) as total FROM tblexpense WHERE ExpenseDate BETWEEN '$date_from' AND '$date_to'");
if ($query) {
    $total_expenses = mysqli_fetch_assoc($query)['total'];
}

$net_balance = $total_income - $total_expenses;

// Get income by category with error handling
$income_by_category = mysqli_query($con, "SELECT IncomeCategory, COALESCE(SUM(IncomeCost), 0) as total 
                                         FROM tblincome 
                                         WHERE IncomeDate BETWEEN '$date_from' AND '$date_to'
                                         GROUP BY IncomeCategory 
                                         ORDER BY total DESC");
if (!$income_by_category) {
    $income_by_category = array();
}

// Get expenses by category with error handling
$expenses_by_category = mysqli_query($con, "SELECT ExpenseCategory, COALESCE(SUM(ExpenseCost), 0) as total 
                                           FROM tblexpense 
                                           WHERE ExpenseDate BETWEEN '$date_from' AND '$date_to'
                                           GROUP BY ExpenseCategory 
                                           ORDER BY total DESC");
if (!$expenses_by_category) {
    $expenses_by_category = array();
}

// Get top users by income with error handling
$top_users_income = mysqli_query($con, "SELECT u.FullName, COALESCE(SUM(i.IncomeCost), 0) as total 
                                       FROM tblincome i 
                                       JOIN tbluser u ON i.UserId=u.ID 
                                       WHERE i.IncomeDate BETWEEN '$date_from' AND '$date_to'
                                       GROUP BY i.UserId 
                                       ORDER BY total DESC 
                                       LIMIT 5");
if (!$top_users_income) {
    $top_users_income = array();
}

// Get top users by expenses with error handling
$top_users_expenses = mysqli_query($con, "SELECT u.FullName, COALESCE(SUM(e.ExpenseCost), 0) as total 
                                         FROM tblexpense e 
                                         JOIN tbluser u ON e.UserId=u.ID 
                                         WHERE e.ExpenseDate BETWEEN '$date_from' AND '$date_to'
                                         GROUP BY e.UserId 
                                         ORDER BY total DESC 
                                         LIMIT 5");
if (!$top_users_expenses) {
    $top_users_expenses = array();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Financial Reports - Expenzo Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: inherit;
            max-width: inherit;
            z-index: 1000;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover {
            background: #34495e;
            padding-left: 25px;
            border-left: 4px solid #3498db;
        }
        .sidebar .active {
            background: #3498db;
            border-left: 4px solid #fff;
        }
        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        .main-content {
            padding: 30px;
            margin-left: 16.666667%;
            min-height: 100vh;
        }
        .page-header {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .page-header h2 {
            color: #2c3e50;
            margin: 0;
            font-weight: 600;
        }
        .page-header hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        .report-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .report-card h4 {
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f8f9fa;
        }
        .report-card h4 i {
            margin-right: 10px;
            color: #3498db;
        }
        .stat-number {
            font-size: 28px;
            font-weight: bold;
            margin: 10px 0;
        }
        .stat-label {
            color: #666;
            font-size: 16px;
        }
        .progress {
            height: 20px;
            margin-bottom: 10px;
            border-radius: 10px;
            background-color: #f8f9fa;
        }
        .progress-bar {
            border-radius: 10px;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            border-top: none;
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 600;
        }
        .table td {
            vertical-align: middle;
        }
        .date-filter {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h3 class="text-center mb-4">Expenzo Admin</h3>
                <nav>
                    <a href="admin_dashboard.php">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                    <a href="manage_users.php">
                        <i class="fa fa-users"></i> Manage Users
                    </a>
                    <a href="manage_expenses.php">
                        <i class="fa fa-money"></i> Manage Expenses
                    </a>
                    <a href="manage_income.php">
                        <i class="fa fa-line-chart"></i> Manage Income
                    </a>
                    <a href="reports.php" class="active">
                        <i class="fa fa-bar-chart"></i> Reports
                    </a>
                    <a href="settings.php">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h2>Financial Reports</h2>
                    <hr>
                </div>

                <!-- Date Range Filter -->
                <div class="date-filter">
                    <form method="GET" class="row">
                        <div class="col-md-4">
                            <label>From Date</label>
                            <input type="date" name="date_from" class="form-control" value="<?php echo $date_from; ?>">
                        </div>
                        <div class="col-md-4">
                            <label>To Date</label>
                            <input type="date" name="date_to" class="form-control" value="<?php echo $date_to; ?>">
                        </div>
                        <div class="col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Update Reports</button>
                        </div>
                    </form>
                </div>

                <!-- Summary Statistics -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="report-card">
                            <h4><i class="fa fa-line-chart"></i> Total Income</h4>
                            <div class="stat-number text-success">₹<?php echo number_format($total_income, 2); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="report-card">
                            <h4><i class="fa fa-money"></i> Total Expenses</h4>
                            <div class="stat-number text-danger">₹<?php echo number_format($total_expenses, 2); ?></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="report-card">
                            <h4><i class="fa fa-balance-scale"></i> Net Balance</h4>
                            <div class="stat-number <?php echo $net_balance >= 0 ? 'text-success' : 'text-danger'; ?>">
                                ₹<?php echo number_format($net_balance, 2); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Income by Category -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="report-card">
                            <h4><i class="fa fa-pie-chart"></i> Income by Category</h4>
                            <?php if(is_object($income_by_category) && mysqli_num_rows($income_by_category) > 0): ?>
                                <?php while($category = mysqli_fetch_assoc($income_by_category)): ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <?php echo htmlspecialchars($category['IncomeCategory']); ?>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-success" role="progressbar" 
                                                     style="width: <?php echo ($total_income > 0 ? ($category['total'] / $total_income) * 100 : 0); ?>%">
                                                    ₹<?php echo number_format($category['total'], 2); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-muted">No income data available for the selected period.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Expenses by Category -->
                    <div class="col-md-6">
                        <div class="report-card">
                            <h4><i class="fa fa-pie-chart"></i> Expenses by Category</h4>
                            <?php if(is_object($expenses_by_category) && mysqli_num_rows($expenses_by_category) > 0): ?>
                                <?php while($category = mysqli_fetch_assoc($expenses_by_category)): ?>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <?php echo htmlspecialchars($category['ExpenseCategory']); ?>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="progress">
                                                <div class="progress-bar progress-bar-danger" role="progressbar" 
                                                     style="width: <?php echo ($total_expenses > 0 ? ($category['total'] / $total_expenses) * 100 : 0); ?>%">
                                                    ₹<?php echo number_format($category['total'], 2); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-muted">No expense data available for the selected period.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Top Users -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="report-card">
                            <h4><i class="fa fa-trophy"></i> Top Users by Income</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Total Income</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_object($top_users_income) && mysqli_num_rows($top_users_income) > 0): ?>
                                            <?php while($user = mysqli_fetch_assoc($top_users_income)): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($user['FullName']); ?></td>
                                                <td>₹<?php echo number_format($user['total'], 2); ?></td>
                                            </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-muted">No income data available for the selected period.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="report-card">
                            <h4><i class="fa fa-trophy"></i> Top Users by Expenses</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Total Expenses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(is_object($top_users_expenses) && mysqli_num_rows($top_users_expenses) > 0): ?>
                                            <?php while($user = mysqli_fetch_assoc($top_users_expenses)): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($user['FullName']); ?></td>
                                                <td>₹<?php echo number_format($user['total'], 2); ?></td>
                                            </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-muted">No expense data available for the selected period.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 