<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get admin details
$adminid = $_SESSION['adminid'];
$adminname = $_SESSION['adminname'];

// Initialize variables with default values
$site_name = '';
$site_email = '';
$currency = '';
$date_format = '';
$timezone = '';

// Fetch settings with error handling
$query = "SELECT * FROM settings WHERE id = 1";
$result = mysqli_query($con, $query);

if ($result === false) {
    // Log the error and display a user-friendly message
    error_log("Database error: " . mysqli_error($con));
    $error_message = "Unable to fetch settings. Please try again later.";
} else {
    if ($row = mysqli_fetch_assoc($result)) {
        $site_name = htmlspecialchars($row['site_name'] ?? '');
        $site_email = htmlspecialchars($row['site_email'] ?? '');
        $currency = htmlspecialchars($row['currency'] ?? '');
        $date_format = htmlspecialchars($row['date_format'] ?? '');
        $timezone = htmlspecialchars($row['timezone'] ?? '');
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $site_name = mysqli_real_escape_string($con, $_POST['site_name']);
    $site_email = mysqli_real_escape_string($con, $_POST['site_email']);
    $currency = mysqli_real_escape_string($con, $_POST['currency']);
    $date_format = mysqli_real_escape_string($con, $_POST['date_format']);
    $timezone = mysqli_real_escape_string($con, $_POST['timezone']);

    // Check if settings exist
    $check_query = "SELECT id FROM settings WHERE id = 1";
    $check_result = mysqli_query($con, $check_query);

    if ($check_result === false) {
        $error_message = "Database error occurred. Please try again.";
    } else {
        if (mysqli_num_rows($check_result) > 0) {
            // Update existing settings
            $update_query = "UPDATE settings SET 
                site_name = '$site_name',
                site_email = '$site_email',
                currency = '$currency',
                date_format = '$date_format',
                timezone = '$timezone'
                WHERE id = 1";
            
            if (!mysqli_query($con, $update_query)) {
                $error_message = "Failed to update settings. Please try again.";
            } else {
                $success_message = "Settings updated successfully!";
            }
        } else {
            // Insert new settings
            $insert_query = "INSERT INTO settings (id, site_name, site_email, currency, date_format, timezone) 
                VALUES (1, '$site_name', '$site_email', '$currency', '$date_format', '$timezone')";
            
            if (!mysqli_query($con, $insert_query)) {
                $error_message = "Failed to save settings. Please try again.";
            } else {
                $success_message = "Settings saved successfully!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Settings - Expenzo Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: inherit;
            max-width: inherit;
            z-index: 1000;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover {
            background: #34495e;
            padding-left: 25px;
            border-left: 4px solid #3498db;
        }
        .sidebar .active {
            background: #3498db;
            border-left: 4px solid #fff;
        }
        .sidebar i {
            width: 25px;
            text-align: center;
            margin-right: 10px;
        }
        .main-content {
            padding: 30px;
            margin-left: 16.666667%;
            min-height: 100vh;
        }
        .page-header {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .page-header h2 {
            color: #2c3e50;
            margin: 0;
            font-weight: 600;
        }
        .page-header hr {
            margin: 15px 0;
            border-color: #f8f9fa;
        }
        .settings-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 10px 15px;
        }
        .form-control:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        .btn-save {
            background: #3498db;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .btn-save:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }
        .alert {
            border-radius: 5px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                min-height: auto;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <h3 class="text-center mb-4">Expenzo Admin</h3>
                <nav>
                    <a href="admin_dashboard.php">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
                    <a href="manage_users.php">
                        <i class="fa fa-users"></i> Manage Users
                    </a>
                    <a href="manage_expenses.php">
                        <i class="fa fa-money"></i> Manage Expenses
                    </a>
                    <a href="manage_income.php">
                        <i class="fa fa-line-chart"></i> Manage Income
                    </a>
                    <a href="reports.php">
                        <i class="fa fa-bar-chart"></i> Reports
                    </a>
                    <a href="settings.php" class="active">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                    <a href="logout.php">
                        <i class="fa fa-sign-out"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <!-- Page Header -->
                <div class="page-header">
                    <h2>System Settings</h2>
                    <hr>
                </div>

                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>

                <!-- Settings Form -->
                <div class="settings-section">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Site Name</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo $site_name; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Site Email</label>
                                    <input type="email" name="site_email" class="form-control" value="<?php echo $site_email; ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Currency</label>
                                    <select name="currency" class="form-control" required>
                                        <option value="USD" <?php echo $currency == 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                                        <option value="EUR" <?php echo $currency == 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                                        <option value="GBP" <?php echo $currency == 'GBP' ? 'selected' : ''; ?>>GBP (£)</option>
                                        <option value="INR" <?php echo $currency == 'INR' ? 'selected' : ''; ?>>INR (₹)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Date Format</label>
                                    <select name="date_format" class="form-control" required>
                                        <option value="Y-m-d" <?php echo $date_format == 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                                        <option value="d-m-Y" <?php echo $date_format == 'd-m-Y' ? 'selected' : ''; ?>>DD-MM-YYYY</option>
                                        <option value="m-d-Y" <?php echo $date_format == 'm-d-Y' ? 'selected' : ''; ?>>MM-DD-YYYY</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Timezone</label>
                                    <select name="timezone" class="form-control" required>
                                        <option value="UTC" <?php echo $timezone == 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                        <option value="America/New_York" <?php echo $timezone == 'America/New_York' ? 'selected' : ''; ?>>Eastern Time</option>
                                        <option value="Europe/London" <?php echo $timezone == 'Europe/London' ? 'selected' : ''; ?>>London</option>
                                        <option value="Asia/Kolkata" <?php echo $timezone == 'Asia/Kolkata' ? 'selected' : ''; ?>>India</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-save">
                                <i class="fa fa-save"></i> Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 