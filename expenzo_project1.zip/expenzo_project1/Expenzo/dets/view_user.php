<?php
session_start();
include('includes/dbconnection.php');

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: admin_login.php");
    exit();
}

// Get user ID from URL
$userid = mysqli_real_escape_string($con, $_GET['id']);

// Get user details
$query = mysqli_query($con, "SELECT * FROM tbluser WHERE ID='$userid'");
$user = mysqli_fetch_assoc($query);

// Get user's expenses
$expense_query = mysqli_query($con, "SELECT * FROM tblexpense WHERE UserId='$userid' ORDER BY ID DESC LIMIT 5");

// Get user's income
$income_query = mysqli_query($con, "SELECT * FROM tblincome WHERE UserId='$userid' ORDER BY ID DESC LIMIT 5");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View User - Expenzo Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>User Details</h2>
                <hr>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-6">
                                <h3 class="panel-title">User Information</h3>
                            </div>
                            <div class="col-md-6 text-right">
                                <a href="manage_users.php" class="btn btn-primary">Back to Users</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Personal Information</h4>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Full Name</th>
                                        <td><?php echo htmlspecialchars($user['FullName']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo htmlspecialchars($user['Email']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Mobile Number</th>
                                        <td><?php echo htmlspecialchars($user['MobileNumber']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Registration Date</th>
                                        <td><?php echo htmlspecialchars($user['RegDate']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php if($user['Status'] == 1): ?>
                                                <span class="label label-success">Active</span>
                                            <?php else: ?>
                                                <span class="label label-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h4>Recent Expenses</h4>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($expense = mysqli_fetch_assoc($expense_query)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($expense['ExpenseDate']); ?></td>
                                            <td><?php echo htmlspecialchars($expense['ExpenseCategory']); ?></td>
                                            <td><?php echo htmlspecialchars($expense['ExpenseCost']); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>

                                <h4>Recent Income</h4>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($income = mysqli_fetch_assoc($income_query)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($income['IncomeDate']); ?></td>
                                            <td><?php echo htmlspecialchars($income['IncomeCategory']); ?></td>
                                            <td><?php echo htmlspecialchars($income['IncomeCost']); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html> 